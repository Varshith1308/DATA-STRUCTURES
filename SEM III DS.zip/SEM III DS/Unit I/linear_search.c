#include<stdio.h>
void search(int[],int,int);
int a[100],i,n,j,flag=0,k;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	search(a,n,k);	
}
void search(int a[],int n,int k)
{
	printf("enter element to be search:");
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		if(a[i]==k)
		{
			flag=1;
			break;
		}
	}
	if(flag==1)
	{
		printf("%d is found",k);
	}
	else
	{
		printf("%d is not found",k);
	}
}

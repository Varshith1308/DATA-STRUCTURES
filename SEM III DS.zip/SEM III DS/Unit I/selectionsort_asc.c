#include<stdio.h>
void selectionsort(int [],int);
int a[100],i,n,j,small=9999,t;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Ascending Order \n");
	selectionsort(a,n);	
}
void selectionsort(int a[],int n)
{
	for(i=0;i<n;i++)
	{
		small=i;
		for(j=i+1;j<n;j++)
		{
			if (a[j]<a[small])
			{
				small=j;
			}
	    }
			if(small!=i)
		    {
		       	t=a[i];
			    a[i]=a[small];
		        a[small]=t;
		    }
    }
    for(i=0;i<n;i++)
	printf("%d\n",a[i]);
}

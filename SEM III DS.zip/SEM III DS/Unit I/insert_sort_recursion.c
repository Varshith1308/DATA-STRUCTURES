#include<stdio.h>
void insertsort(int [],int);
int a[100],i,n,j,k;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Ascending Order \n");
	insertsort(a,n);
	for(i=0;i<n;i++)
	printf("%d\n",a[i]);		
}
void insertsort(int a[],int n)
{
	if(n<=1)
	return;
	insertsort(a,n-1);
	k=a[n-1];
	j=n-2;
	while(j>=0 && a[j]>k)
	{
			a[j+1]=a[j];
			j=j-1;
	}
		a[j+1]=k;
}	


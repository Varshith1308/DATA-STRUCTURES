#include<stdio.h>
void Bubblesort1(int[],int);
void Bubblesort2(int[],int);
main()
{
	int a[100],i,n,j;
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(j=0;j<n;j++)
	{
		scanf("%d",&a[j]);
	}
	printf("\n Descending Order \n");
	Bubblesort1(a,n);  
	printf("\n Ascending Order \n");
	Bubblesort2(a,n);  	
}
void Bubblesort1(int a[],int n)
{
	int t,i,j;
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if (a[j]>a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
		printf("%d\n",a[j]);
	}
}
void Bubblesort2(int a[],int n)
{
	int t,i,j;
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if (a[j]<a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
		printf("%d\n",a[j]);
	}
}

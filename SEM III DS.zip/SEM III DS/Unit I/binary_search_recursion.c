#include<stdio.h>
int search(int,int,int);
int a[100],mid,l,n,i,h,k,b;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	l=1;
	h=n;
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter element to be search:"); 
	scanf("%d",&k);
	b=search(l,h,k);
	if(b==-1)	
	printf("%d is not present in the list",k);
	else
	printf("%d is found at position %d in the list",k,b);	
}
int search(int l,int h,int k)
{
	if(l<=h)
	{
		mid=(l+h)/2;
		if(k==a[mid])
		{
		    return mid;
	    }
	    else if(k<a[mid])
	    {
		    return search(l,mid-1,k);
		}
		else
		{
	        return search(mid+1,h,k);
	    }
	}
	return -1;
}

#include<stdio.h>
int search(int[],int,int);
int a[100],mid,l,n,i,h,k,b;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("enter element to be search:");
	scanf("%d",&k);
	b=search(a,n,k);
	if(b==-1)	
	printf("%d is not present in the list",k);
	else
	printf("%d is found at position %d in the list",k,b);	
}
int search(int a[],int n,int k)
{
	l=1;
	h=n;
	while(l<=h)
	{
		mid=(l+h)/2;
		if(k==a[mid])
		return mid;
		else if(k<a[mid])
		h=mid-1;
		else
		l=mid+1;
	}
	return -1;
}


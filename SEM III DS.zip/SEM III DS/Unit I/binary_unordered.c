#include<stdio.h>
int search(int[],int,int);
void Bubblesort(int [],int);
int a[100],mid,l,n,i,h,k,b;
main()
{
	int a[100],i,n,j;
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(j=0;j<n;j++)
	{
		scanf("%d",&a[j]);
	}
	printf("\n Ascending Order \n");
	Bubblesort(a,n);
	printf("enter element to be search:");
	scanf("%d",&k);
	b=search(a,n,k);
	if(b==-1)	
	printf("%d is not present in the list",k);
	else
	printf("%d is found at postion %d in the list",k,b);		
}
void Bubblesort(int a[],int n)
{
	int t,i,j;
	for(i=0;i<=n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if (a[j]<a[j+1])
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
		printf("%d\n",a[j]);
	}
}
int search(int a[],int n,int k)
{
	l=1;
	h=n;
	while(l<=h)
	{
		mid=(l+h)/2;
		if(k==a[mid])
		return mid;
		else if(k<a[mid])
		h=mid-1;
		else
		l=mid+1;
	}
	return -1;
}


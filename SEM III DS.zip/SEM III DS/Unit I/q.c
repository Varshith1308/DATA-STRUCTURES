#include<stdio.h>
int quicksort(int a[],int p,int r);
int main()
{
	int a[12],n,i,p,r;
	printf("enter the array size:");
	scanf("%d",&n);
	printf("enter the elements:");
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
      quicksort(a,1,n);
      for(i=1;i<=n;i++){
      	printf("%d",a[i]);
	  }
}
int quicksort(int a[],int p,int r)
{
    int q;
	if(p<r)
	{
		q=partition(a,p,r);
		quicksort(a,p,q-1);
		quicksort(a,q+1,r);
	}
}
int partition(int a[],int p,int r)
{
	int pivot,t,temp,i,j,n;
	pivot=a[r];
	i=p-1;
	for(j=p;j<=r-1;j++)
	{
		if(a[j]<=pivot)
		{
			i=i+1;
			t=a[i];
			a[i]=a[j];
			a[j]=t;
		}
	}
		temp=a[i+1];
		a[i+1]=a[r];
		a[r]=temp;
		return i+1;
	
}

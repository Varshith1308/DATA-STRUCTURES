#include<stdio.h>
void insertsort(int[],int);
int a[100],i,n,j,k;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Ascending Order \n");
	insertsort(a,n);	
}
void insertsort(int a[],int n)
{
	for(i=1;i<n;i++)
	{
		k=a[i];
		j=i-1;
		while(j>=0 && a[j]>k)
		{
			a[j+1]=a[j];
			j=j-1;
		}
		a[j+1]=k;
	}
	for(i=0;i<n;i++)
	printf("%d\n",a[i]);	
}


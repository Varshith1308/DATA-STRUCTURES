#include<stdio.h>
void selectionsort(int [],int);
int a[100],i,n,j,large=0,t;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Descending Order \n");
	selectionsort(a,n);	
}
void selectionsort(int a[],int n)
{
	for(i=0;i<n;i++)
	{
		large=i;
		for(j=i+1;j<n;j++)
		{
			if (a[j]>a[large])
			{
				large=j;
			}
	    }
			if(large!=i)
		    {
		       	t=a[i];
			    a[i]=a[large];
		        a[large]=t;
		    }
    }
    for(i=0;i<n;i++)
	printf("%d\n",a[i]);
}

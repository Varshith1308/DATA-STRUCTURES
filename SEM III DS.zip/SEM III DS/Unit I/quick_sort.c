#include<stdio.h>
int quicksort(int[],int,int);
int a[100],pivot,i,n,j,r,p,q,t,s;
main()
{
	printf("enter n value:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	printf("\n Elements After Sorting \n");
	quicksort(a,1,n);
	for(i=1;i<=n;i++)
	printf("%d\n",a[i]);		
}
int quicksort(int a[],int p,int r)
{
	if(p<r)
	{
	  q=partition(a,p,r);
	  quicksort(a,p,q-1);
	  quicksort(a,q+1,r);
    } 
}
int partition(int a[],int p,int r)
{
	pivot=a[r];
	i=p-1;
	for(j=p;j<=r-1;j++)
	{
		if(a[j]<=pivot)
		{
			i=i+1;
			t=a[i];
			a[i]=a[j];	
			a[j]=t;		
		}
	}
	s=a[i+1];
    a[i+1]=a[r];	
    a[r]=s;
	return i+1;
}

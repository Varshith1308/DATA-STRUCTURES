#include<stdio.h>
#include<stdlib.h>
int ch,ch1,x,n,i,lh,rh;

struct node
{
	int data;
	struct node*left,*right;
	int ht;
}node;

struct node*insert();
struct node*deletion(); 
struct node*search();
void inorder();
void sprint();

main()
{
	struct node*root=NULL;
	do
	{
		printf("\n1.Insert an element");
		printf("\n2.Display elements");
		printf("\n3.Search an element");
		printf("\n4.Delete an element");
		printf("\nenter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("\nenter no of elements:");
				   scanf("%d",&n);
				   printf("\nenter the tree data:");
				   for(i=0;i<n;i++)
				   {
					   scanf("%d",&x);
					   root=insert(root,x);
				   }
			       break;
			case 2:printf("\nInorder Sequence:");
				   inorder(root);
			       break;
			case 3:printf("\nenter the value to be searched:");
				   scanf("%d",&x);
				   root=search(root,x);       	
				   sprint(root);
			       break;
			case 4 :printf("\nenter the value to be deleted:\n");  
                    scanf("%d",&x);  
              	    root=deletion(root,x);
                    inorder(root); 
                    break;
		}
		printf("\npress 1 to continue:");
		scanf(" %d",&ch1);
	}while(ch1==1);
}

int height(struct node*T)
{
	if(T==NULL)
		return(0);
	
	if(T->left==NULL)
		lh=0;
	else
		lh=1+T->left->ht;
	
	if(T->right==NULL)
		rh=0;
	else
		rh=1+T->right->ht;

	if(lh>rh)
		return(lh);
	
	return(rh);
}
int BF(struct node*T)
{
	if(T==NULL)
		return(0);
	
	if(T->left==NULL)
		lh=0;
	else
		lh=1+T->left->ht;

	if(T->right==NULL)
		rh=0;
	else
		rh=1+T->right->ht;

	return(lh-rh);
}
struct node*rotateright(struct node*x)
{
	struct node*y;
	
	y=x->left;
	x->left=y->right;
	y->right=x;
	
	x->ht=height(x);
	y->ht=height(y);
	
	return(y);
}
struct node*rotateleft(struct node*x)
{
	struct node*y;
	
	y=x->right;
	x->right=y->left;
	y->left=x;
	
	x->ht=height(x);
	y->ht=height(y);
	
	return(y);
}

struct node*RR(struct node*T)
{
	T=rotateleft(T);
	return(T);
}

struct node*LL(struct node*T)
{
	T=rotateright(T);
	return(T);
}

struct node*LR(struct node*T)
{
	T->left=rotateleft(T->left);
	T=rotateright(T);
	return(T);
}

struct node*RL(struct node*T)
{
	T->right=rotateright(T->right);
	T=rotateleft(T);
	return(T);
}
struct node*insert(struct node*T,int x)
{
	if(T==NULL)
	{
		T=(struct node*)malloc(sizeof(node));
		T->data=x;
		T->left=NULL;
		T->right=NULL;
	}
	else
	if(x>T->data)
	{
		T->right=insert(T->right,x);
		if(BF(T)==-2)
			if(x>T->right->data)
				T=RR(T);
			else
				T=RL(T);
	}
	else
	if(x<T->data)
	{
		T->left=insert(T->left,x);
		if(BF(T)==2)
			if(x<T->left->data)
				T=LL(T);
			else
				T=LR(T);
	}
	T->ht=height(T);
	return(T);
}
void inorder(struct node*T)
{
	if(T!=NULL)
	{
		inorder(T->left);
		printf("%d",T->data,BF(T));
		inorder(T->right);
	}
}
struct node*deletion(struct node*T,int x)
{
	struct node*p;
	if(T==NULL)
		return NULL;
	else
		if(x>T->data)
		{
			T->right=deletion(T->right,x);
			if(BF(T)==2)
				if(BF(T->left)>=0)
					T=LL(T);
				else
					T=LR(T);
		}
		else
			if(x<T->data)
			{
				T->left=deletion(T->left,x);
				if(BF(T)==-2)
					if(BF(T->right)<=0)
						T=RR(T);
					else
						T=RL(T);
			}
			else
			{
				if(T->right!=NULL)
				{
					p=T->right;
					while(p->left!=NULL)
						p=p->left;
					T->data=p->data;
					T->right=deletion(T->right,p->data);
					if((BF(T)==2))
						if(BF(T->left)>=0)
							T=LL(T);
						else
							T=LR(T);
				}
				else
					return(T->left);
			}
			T->ht=height(T);
	return(T);
}
struct node*search(struct node*rootnode,int s)
{
    if(rootnode==NULL || rootnode->data==s)   
        return rootnode;
    else if(s > rootnode->data) 
        return search(rootnode->right,s);
    else
        return search(rootnode->left,s);
}
void sprint(struct node*rootnode) 
{
	if (rootnode != NULL)
		printf("%d = Search element found", rootnode->data);
	else
		printf("Search element not found");
}


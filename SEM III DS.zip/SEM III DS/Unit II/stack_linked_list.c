#include<stdio.h>
#include<stdlib.h>

int ch,ch1,n;

void push(int);
void display();
int pop();
int peek();

struct node
{
    int data;
	struct node*link;	
}*top=NULL;

main()
{
	do
	{
		printf("1.Push an element\n");
		printf("2.Display elements\n");
		printf("3.Pop an element\n");
		printf("4.Top of the linked list\n");
		printf("enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter an element to be inserted:");
			       scanf("%d",&n);
			       push(n);
			       break;
			case 2:display();
			       break;
			case 3:printf("popped element:%d",pop());
			       break;
			case 4:printf("Top of the element:%d",peek());
			       break;		       
		}
		printf("\n press 1 to continue:");
		scanf(" %d",&ch1);		
	}while(ch1==1);
}

void push(int data)
{
	struct node*newp;
	newp=malloc(sizeof(newp));
	if(newp==NULL)
	printf("stack is full\n");
	newp->data=n;
	newp->link=NULL;
	
	newp->link=top;
	
	top=newp;
}

void display()
{
	struct node*temp;
	temp=top;
	printf("elements in the list:\n");
	while(temp!=NULL)
	{
	   printf("%d\n",temp->data);
	   temp=temp->link;	
    }
}

int pop()
{
	struct node*temp;
	int val;
	temp=top;
	if(top==NULL)
	{
		printf("stack is empty\n");
	}
	val=temp->data; // to store first node data some where
	top=temp->link;
	free(temp);
	temp=NULL;	
	return val;
}

int peek()
{
	if(top==NULL)
	printf("stack is empty\n");
	return top->data;
}

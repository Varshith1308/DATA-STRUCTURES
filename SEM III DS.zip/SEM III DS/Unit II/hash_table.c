#include <stdio.h>
struct pair
{
    int key,value;
};
int main() 
{
    int size , i , numbers;
    
    struct pair hash[size];
    
    printf("\n Enter the size of the table");
    scanf("%d",&size);
    	
    printf("\n Enter the elements :");
    for(i=0;i<size;i++)
    {
        scanf("%d",&numbers);
        hash[numbers%size].value = numbers;
        hash[numbers%size].key= numbers % size;
    }
    printf("\n key \t value");
    for(i=0;i<size;i++)
        	printf("\n %d \t %d",hash[i].key,hash[i].value);
    return 0;
}



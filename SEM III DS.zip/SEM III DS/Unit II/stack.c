#include<stdio.h>
#include<stdlib.h>
#define MAX 20
int a[MAX],top,ch,x,ch1,n,i;

void stack();
int empty();//with push operation
int full();//with pop operation
int size();
int peek(); //display the first element of the stack
void push(int);
int pop();//delete the first element of the stack
void display();

main()
{
   	stack();
    do
   	{
   		printf("1.Push an element onto the stack\n");
   		printf("2.Pop an element from the stack\n");
   		printf("3.Display the top element\n");
   		printf("4.Display all stack elements\n");
   		printf("5.Display size of stack\n");
   		printf("enter your choice:");
   		scanf("%d",&ch);
   		switch(ch)
   		{
   			case 1:printf("enter element to be pushed:");
   			       scanf("%d",&x);
   			       push(x);
   			       break;
   			case 2:x=pop();
   			       printf("popped element:%d\n",x);
   			       break;
   			case 3:printf("top of the element:%d\n",peek());
   			       break;
   			case 4:display();
   			       break;
   			case 5:printf("size of stack:%d\n",size());
   			       break;
		}
   		printf("\npress 1 to continue");
   		scanf(" %d",&ch1);
	   }while(ch1==1);

}
void stack()
{
	top=-1;
}
int size()
{
    return top+1;	
}
int empty()
{
	if(top==-1)
	return 1;
	else
	return 0;
}
int full()
{
    if(top==MAX-1)
	return 1;
	else
	return 0;		
}
void push(int x)
{
	if(full())
	{
		printf("stack overflow\n");
	}
	top=top+1;
	a[top]=x;
}
int pop()
{
	if(empty())
	{
		printf("stack underflow\n");
	}
	x=a[top];
	top=top-1;
	return x;
}
int peek()
{
	if(empty())
	{
		printf("stack underflow\n");
	}
	return a[top];
}
void display()
{
	if(empty())
	{
		printf("stack is empty\n");
	}
	printf("stack elements:\n");
	for(i=top;i>=0;i--)
	{
		printf("%d\n",a[i]);
	}
}


#include<stdio.h>
#include<stdlib.h>

int count=0;

void count_nodes();
void display();
void insert_atend();
struct node*insert_atbegin();

struct node
{
	int data;
	struct node*link;
};
main()
{
	struct node*head=NULL;
	head=malloc(sizeof(struct node));
	head->data=6;
	head->link=NULL;
	printf("\nFIRST NODE\n");
	printf("%d\n",head->data);// 6
	printf("%d\n",head->link);// NULL
	
	struct node*current=malloc(sizeof(struct node)); // for second node(new node is created)
	current->data=10;
	current->link=NULL;
	head->link=current;
	printf("\nSECOND NODE\n");
	printf("%d\n",current->data);// 10
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link);// address of first node(6)
	
	current=malloc(sizeof(struct node));// third node (it no longers points to second node)
	current->data=12;
	current->link=NULL;
	head->link->link=current;// address of second node
	printf("\nTHIRD NODE\n");
	printf("%d\n",current->data);// 12
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link->data);// variable in second node(10)
	printf("%d\n",head->link->link);// address of second node(10)
	
	current=malloc(sizeof(struct node));// third node (it no longers points to second node)
	current->data=15;
	current->link=NULL;
	head->link->link->link=current;// address of third node
	printf("\nFOURTH NODE\n");
	printf("%d\n",current->data);// 15
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link->link->data);// variable in third node(12)
	printf("%d\n",head->link->link->link);// address of third node(12)
	
	count_nodes(head);
	display(head);
	insert_atend(head,60);
	display(head);
	head=insert_atbegin(head,50);
	display(head);
}

void count_nodes(struct node *head)
{
	if(head==NULL)
	{
	   printf("Linked list is empty");
    }
	struct node *temp=head;
	while(temp!=NULL)
	{
		count=count+1;
		temp=temp->link;
	}
	printf("\nno.of nodes:%d\n\n",count);// no.of nodes(4)
}

void display(struct node *head)
{
	if(head==NULL)
	{
	   printf("Linked list is empty");
    }
	struct node *temp=head;
	printf("elements in nodes:\n");
	while(temp!=NULL)
	{
		printf("%d\n",temp->data);// to print all nodes 
		temp=temp->link;
	}
}

// To insert a node at the end

void insert_atend(struct node *head,int data)
{
	struct node *temp,*ptr;
	temp=head;
	ptr=malloc(sizeof(struct node));
	ptr->data=data;
	ptr->link=NULL;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}
	temp->link=ptr;
}

// To insert a node at the begining

struct node*insert_atbegin(struct node*head,int data)
{
	struct node *ptr;
	ptr=malloc(sizeof(struct node));
	ptr->data=data;//50
	ptr->link=head;
	head=ptr;
	return head;
}

// To insert a node at particular position




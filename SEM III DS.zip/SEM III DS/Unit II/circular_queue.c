#include<stdio.h>
#define MAX 3
int initializequeue(int x);
int isfull();
int isempty();
int enqueue(int x);
int dequeue();
int size();
int peek();
void display();
int q[MAX],rear,front,ch,ch1,x,i,c=0;
main()
{
	intializequeue();
	do
	{	
		printf("1.enqueue an element into queue\n");
		printf("2.dequeue an element from queue\n");
		printf("3.Display the top element of queue\n");
		printf("4.Display all the queue elements\n");
		printf("5.Display size of queue\n");
		printf("enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter element to be enqeued:");
				   scanf("%d",&x);
				   enqueue(x);
				   break;
			case 2:x=dequeue();
				   printf("deleted element:%d",x);
				   break;
			case 3:printf("top of the element:%d",peek());
				   break;
			case 4:display();
				   break;
			case 5:printf("size of stack is:%d\n",size());
				   break;	
		}printf("\n press 1 to continue:");
		 scanf(" %d",&ch1);
	}while(ch1==1);
}
int intializequeue()
{
	rear=-1;
	front=-1;
}
int isempty()
{
	if(front==-1)
	return 1;
	else
	return 0;
}
int isfull()
{
	if((front==0 && rear==MAX-1) || front==rear+1)
	return 1;
	else 
	return 0;
}
int size()
{
	if(isempty())
	{
		printf("queue is empty");
		return;
	}
	else 
	i=front;
	if(front<=rear)
	{
		while(i<=rear)
		{
			printf("%d",q[i++]);
			c=c+1;
		}
	}
	else
	{
		while(i<=MAX-1)
		{
			printf("%d",q[i++]);
			c=c+1;
			i=0;
		}
		while(i<=rear)
		{
			printf("%d",q[i++]);
			c=c+1;
		}
	}
	return c;
	
}
int enqueue(int x)
{
	if(isfull())
	{
		printf("queue is full");
		return;
	}
	else
	{	
	    if(front==-1)
	    {
	      front=0;
        }
        if(rear==MAX-1)
        {
          rear=0;	
        }
        else
        {   
	      rear=rear+1;
        }
	    q[rear]=x;
    }
}
int dequeue()
{	
	if(isempty())
	{
		printf("queue is empty");
	}
	else
	{
	    x=q[front];
	    if(front==rear)
	    {
	      front=-1;
	      rear=-1;	
	    }
	    else if(front==MAX-1)
	    {
		   front=0;
	    }
	    else
	   {
	       front=front+1;
       }
     return x;
    }
}
int peek()
{
	if(isempty())
    printf("queue is empty");
	else
	return q[front];
}
void display()
{
	if(isempty())
	{
		printf("queue is empty");
	}
	else
	{
		i=front;
		if(front<=rear)
		{
			while(i<=rear)
			printf("%d\n",q[i++]);
		}
		else
		{
			while(i<=MAX-1)
			printf("%d",q[i++]);
			i=0;
			while(i<=rear)
			{
				printf("%d\n",q[i++]);
			}
        }
    }
}

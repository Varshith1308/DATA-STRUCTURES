#include<stdio.h>
#include<stdlib.h>

int count=0,ch,ch1,n,large=0,small=9999999,sum=0;

void count_nodes();	
void display();
void insert();
struct node*addnode();
int max_node();
int min_node();
int sum_nodes();
void even_next_odd();
void loop();

struct node
{
	int data;
	struct node*link;
};

main()
{
	struct node*head=NULL;
	do
	{
		printf("1.Add a node\n");
		printf("2.Insert a node\n");
		printf("3.To display all elements\n");
	    printf("4.Total no.of nodes\n");
	    printf("5.Maximum node\n");
	    printf("6.Minimum node\n");
	    printf("7.Sum of nodes\n");
	    printf("8.Even next odd\n");
	    printf("9.Finding a Loop\n");
		printf("enter your choice:");
        scanf("%d",&ch);
	    switch(ch)
	    {
	    	case 1:printf("enter an element to be inserted:");
	    	       scanf("%d",&n);
	    	       head=addnode(head,n);
	    	       break;
	    	case 2:printf("enter an element to be inserted:");
	    	       scanf("%d",&n);
	    	       insert(head,n);
	    	       break;
	    	case 3:display(head);
	    	       break;
	        case 4:count_nodes(head);
	               break;
	        case 5:max_node(head);
	               break;
	        case 6:min_node(head);
	               break;
	        case 7:sum_nodes(head);
	               break;
	        case 8:even_next_odd(head);
	               display(head);
	               break;
	        case 9:loop(head);
	               break;
	               
	   }printf("\npress 1 to continue:");
	    scanf(" %d",&ch1);
	   
    }while(ch1==1);

}

struct node*addnode(struct node*head,int data)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->data=data;
	temp->link=NULL;
	head=temp;
	return head;	
}

void count_nodes(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node *temp=head;
	while(temp!=NULL)
	{
		count=count+1;
		temp=temp->link;
	}
	printf("\nno.of nodes:%d\n\n",count);
}

void display(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node*temp=head;
	printf("elements in nodes:\n");
	while(temp!=NULL)
	{
		printf("%d\n",temp->data);
		temp=temp->link;
	}
}

void insert(struct node*head,int n)
{
	struct node*temp,*ptr;
	temp=head;
	ptr=malloc(sizeof(struct node));
	ptr->data=n;
	ptr->link=NULL;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}
	temp->link=ptr;
}

int max_node(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node*temp=head;
	while(temp!=NULL)
	{
		if((temp->data)>large)
	    {
		  large=temp->data;
	    }
		temp=temp->link;
	}
	printf("maximum node:%d\n",large);	
	
}

int min_node(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node*temp=head;
	while(temp!=NULL)
	{
		if((temp->data)<small)
	    {
		  small=temp->data;
	    }
		temp=temp->link;
	}
	printf("minimum node:%d\n",small);	
	
}

int sum_nodes(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node*temp=head;
	while(temp!=NULL)
	{
		sum=sum+temp->data;
		temp=temp->link;
	}
	printf("sum of nodes:%d\n",sum);	
}

void even_next_odd(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node*temp=head,*p=head;
	int temp1;//for exchange
	while(p!=NULL)
	{
		if((p->data)%2==0)
		{
		   temp1=temp->data;
		   temp->data=p->data;
		   p->data=temp1;
		   temp=temp->link;
	    }
	    p=p->link;
	}
}

void loop(struct node*head)
{
	struct node*p=head;
	struct node*q=head;
	do
	{
		p=p->link;
		q=q->link->link;
	}while(p!=NULL && q!=NULL && p!=q);
	
	if(p==q)
	printf("loop is present");
	else
	printf("loop is not present");
}
		
	

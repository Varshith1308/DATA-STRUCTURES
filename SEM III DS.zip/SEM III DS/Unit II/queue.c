#include<stdio.h>
#include<stdlib.h>
#define MAX 8
int q[MAX],rear,front,ch,x,ch1,i;

void queue();
int empty();
int full();
int size();
void enqueue(int);
int dequeue();
int peek();
void display();

main()
{
   	queue();
    do
   	{
   		printf("1.Insert an element onto the queue\n");
   		printf("2.Delete an element from the queue\n");
   		printf("3.Display the first element\n");
   		printf("4.Display all queue elements\n");
   		printf("5.Display size of queue\n");
   		printf("enter your choice:");
   		scanf("%d",&ch);
   		switch(ch)
   		{
   			case 1:printf("enter element to be inserted:");
   			       scanf("%d",&x);
   			       enqueue(x);
   			       break;
   			case 2:x=dequeue();
   			       printf("deleted element:%d\n",x);
   			       break;
   			case 3:printf("first element:%d\n",peek());
   			       break;
   			case 4:display();
   			       break;
   			case 5:printf("size of queue:%d\n",size());
   			       break;
		}
   		printf("\npress 1 to continue");
   		scanf(" %d",&ch1);
	   }while(ch1==1);

}
void queue()
{
	rear=-1;
	front=-1;
}
int empty()
{
	if(front==-1 || front==rear+1)
	return 1;
	else
	return 0;
}
int full()
{
    if(rear==MAX-1)
	return 1;
	else
	return 0;		
}
int size()
{
	if(empty())
	printf("queue is empty");
	else
    return rear-front+1;	
}
void enqueue(int x)
{
	if(full())
	{
		printf("queue is full\n");
	}
	else 
	if(front==-1)
	{
	   front=0;
    }
	   rear=rear+1;
	   q[rear]=x;
}
int dequeue()
{
	if(empty())
	{
		printf("queue is empty\n");
	}
	else
	{
	    x=q[front];
	    front=front+1;
	    return x;
    }   
}
int peek()
{
	if(empty())
	{
		printf("queue is empty\n");
	}
	else
	{
     	return q[front];
    }
}
void display()
{
	if(empty())
	{
		printf("queue is empty\n");
	}
	else
	{
	printf("queue elements:\n");
	for(i=front;i<=rear;i++)
	{
		printf("%d\n",q[i]);
	}
   }
}


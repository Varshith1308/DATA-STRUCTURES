#include<stdio.h>
#include<stdlib.h>

int ch1,ch,n,pos;

struct node*insertatempty();
struct node*insertatbegin();
void display();
struct node*insertatend();
struct node*insertatpartpos();
struct node*delatbegin();
struct node*delatend();
struct node*delatpartpos();

struct node
{
	int data;
	struct node*prev;
	struct node*next;	
};

main() 
{
	int data;
	struct node*tail;
	do
	{
		printf("1.Add a node\n");
		printf("2.Insert at begin\n");
		printf("3.Display nodes\n");
		printf("4.Insert at end\n");
		printf("5.Insert at particular position\n");
		printf("6.Delete at begin\n");
		printf("7.Delete at end\n");
		printf("8.Delete at particular position\n");
		printf("enter your choice:");
	    scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatempty(tail,n);
				   break;
		    case 2:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatbegin(tail,n);
		           printf("\nelement inserted");
		           break;
		    case 3:printf("elements in nodes\n");
		           display(tail);
		           break;
		    case 4:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatend(tail,n);
		           printf("\nelement inserted");
		           break;
		    case 5:printf("enter element to be inserted:");
		           scanf("%d",&n);
		           printf("enter position:");
		           scanf("%d",&pos);
			       tail=insertatpartpos(tail,n,pos);
		           printf("\nelement inserted");
		           break;
		    case 6:tail=delatbegin(tail);
		           printf("\nelement deleted");
		           break;
		    case 7:tail=delatend(tail);
		           printf("\nelement deleted");
		           break;
		    case 8:printf("enter position:");
		           scanf("%d",&pos);
			       tail=delatpartpos(tail,pos);
		           printf("\nelement deleted");
		           break;
		    
		}
		printf("\n press 1 to continue:");
		scanf(" %d",&ch1);
	}while(ch1==1);
}

struct node*insertatempty(int data)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->prev=temp;
	temp->data=data;
	temp->next=temp;
	return temp;
}

struct node*insertatbegin(struct node*tail,int data)
{
	struct node *newp =insertatempty(data);
	struct node*temp=tail->next;
	newp->prev=tail;
	newp->next=temp;
	temp->prev=newp;
	tail->next=newp;
	return tail;	
}

struct node*insertatend(struct node*tail,int data)
{
	struct node*newp=insertatempty(data);
	struct node*temp=tail->next;
	newp->next=temp;
	newp->prev=tail;
	tail->next=newp;
	temp->prev=newp;
	tail=newp;
	return tail;
}

void display(struct node*tail)
{
	if(tail==NULL)
	printf("List is empty\n");
	struct node*temp=tail->next;
	do
	{
		printf("%d\n",temp->data);
		temp=temp->next;
	}while(temp!=tail->next);
}

struct node*insertatpartpos(struct node*tail,int data,int pos)
{
	struct node*newp=insertatempty(data);
	struct node*temp=tail->next;
	while(pos>1)
	{
		temp=temp->next;
		pos--;
	}
	newp->prev=temp;
	newp->next=temp->next;
	temp->next->prev=newp;
	temp->next=newp;
	if(temp==tail)
	{
		tail=tail->next;
	}
	return tail;
}

struct node*delatbegin(struct node*tail)
{
	struct node*temp=tail->next;
	if(temp==tail)
	{
		free(tail);
		tail=NULL;
		return tail;
	}
	
	tail->next=temp->next;
	temp->next->prev=tail;
	free(temp);
	return tail;
}

struct node*delatend(struct node*tail)
{
	struct node*temp;
	if(temp==tail)
	{
		free(tail);
		tail=NULL;
		return tail;
	}
	temp=tail->prev;
	temp->next=tail->next;
	tail->next->prev=temp;
	free(tail);
	tail=temp;
	return tail;
}
struct node*delatpartpos(struct node*tail,int data,int pos)
{
	struct node*temp=tail->next;
	while(pos>1)
	{
		temp=temp->next;
		pos--;
	}
	struct node*temp2=temp->prev;
	temp2->next=temp->next;
	temp->next->prev=temp2;
	free(temp);
	if(temp==tail)
	{
		tail=temp2;
	}
	return tail;
}

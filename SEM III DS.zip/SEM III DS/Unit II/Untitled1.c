#include<stdio.h>
#include<stdlib.h>

void display();
struct node*addempty();
struct node*addbegin();
struct node*addend();
struct node*delbegin();
struct node*delend();


int ch,ch1,n;

struct node
{
	int data;
	struct node*link;
};

main()
{
	struct node*tail;
	do
	{
		printf("1.Add at empty\n 2.Display\n3.Begin Insert\n 4.Insert end\n5.Delete begin\n 6.Delete end");
		printf("enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
		     case 1:printf("enter element to be inserted:");
		            scanf("%d",&n);
		            tail=addempty(tail,n);
		            break;	    
		     case 2:display(tail);
		            break;
		     case 3:printf("enter element to be inserted:");
		            scanf("%d",&n);
		            tail=addbegin(tail,n);
		            break;
		     case 4:printf("enter element to be inserted:");
		            scanf("%d",&n);
		            tail=addend(tail,n);
		            break;
		     case 5:
		            tail=delbegin(tail);
		            break;
			case 6:
		            tail=delend(tail);
		            break;		
		             
		}
		printf("\n press 1 to continue:");
		scanf(" %d",&ch1);
	}while(ch1==1);
}

struct node*addempty(struct node*tail,int n)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->data=n;
	temp->link=temp;
	return temp;
}

void display(struct node*tail)
{
	struct node*temp=tail->link;
	printf("elements in nodes:\n");
	do
	{
		printf("%d\n",temp->data);
		temp=temp->link;
	}while(temp!=tail->link);
	
}

struct node*addbegin(struct node*tail,int n)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->data=n;
    temp->link=tail->link;
    tail->link=temp;
	return tail;
}

struct node*addend(struct node*tail,int n)
{
	struct node*ptr;
	ptr=malloc(sizeof(struct node));
	ptr->data=n;
	ptr->link=NULL;
	ptr->link=tail->link;
	tail->link=ptr;
	tail=tail->link;
	return tail;
}

struct node*delbegin(struct node*tail)
{
	struct node*temp;
	temp=tail->link;
	tail->link=temp->link;
	free(temp);
	temp=NULL;
	return tail;	
}

struct node*delend(struct node*tail)
{
	struct node*temp=tail->link;
	while(temp->link!=tail)
	{
		temp=temp->link;
	}
	temp->link=tail->link;
	free(tail);
	tail=temp;
	return tail;

}

#include<stdio.h>
#include<ctype.h>
#include<math.h>

char stack[100],x,y,z;
int n;
int top=-1;

void push(char x)
{
	stack[++top]=x;
}
char pop()
{
	if(top==-1)
	    return -1;
	else
	    return stack[top--];
}
main()
{
	char exp[100],*e,x;
	printf("enter expression:");
	scanf("%s",exp);
	e=exp;
	while(*e!='\0')
	{
		if(isalnum(*e))
		{
			n=*e-48;
			push(n);
	    }
		else 
		{
			x=pop();
			y=pop();
			switch(*e)
			{
				case '+':z=y+x;
					     break;
				case '-':z=y-x;
				         break;
				case '*':z=y*x;
				         break;
				case '/':z=y/x;
				         break;
				case '^':z=pow(y,x);
				         break;
		  }
		     push(z);
   }
   e++;
}
printf("\n the result:%d",pop());
return 0;
}

		
				  
				
		

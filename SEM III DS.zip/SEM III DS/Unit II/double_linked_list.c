#include<stdio.h>
#include<stdlib.h>

int ch,ch1,n,pos;

struct node*addatEmpty();
struct node*addatBegin();
struct node*addatpartpos();
struct node*addatEnd();
struct node*delatbegin();
struct node*delatend();
struct node*delatpartpos();
struct node*reverse();
void display();

struct node
{
	struct node*prev;
	int data;
	struct node*next;
};

main()
{
	struct node*head=NULL;
	//head=malloc(sizeof(struct node));    static
	//head->prev=NULL;
	//head->data=10;
	//head->next=NULL;
	//printf("%d\n",head->data);
	do
	{
		printf("1.Add a node\n");
		printf("2.Display nodes\n");
		printf("3.Add a node at the begining\n");
		printf("4.Add a node at the end\n");
		printf("5.Add a node at the particular position\n");
		printf("6.Delete a node at the begining\n");
		printf("7.Delete a node at the end\n");	
		printf("8.Delete a node at the particular position\n");	
		printf("9.Reverse of nodes\n");
		printf("enter your choice:");
		scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("enter an element:");
		       scanf("%d",&n);
		       head=addatEmpty(head,n);
		       break;
		case 2:display(head);
		       break;
		case 3:printf("enter an element to be inserted:");
		       scanf("%d",&n);
		       head=addatBegin(head,n);
		       printf("\nelement inserted");
		       break;
		case 4:printf("enter an element to be inserted:");
		       scanf("%d",&n);
		       head=addatEnd(head,n);
		       printf("\nelement inserted");
		       break;
		case 5:printf("enter an element to be inserted:");
		       scanf("%d",&n);
		       printf("enter position:");
		       scanf("%d",&pos);
		       head=addatpartpos(head,n,pos);
		       printf("\nelement inserted");
		       break;
	    case 6:head=delatbegin(head);
		       printf("\nelement deleted");
		       break; 
	    case 7:head=delatend(head);
		       printf("\nelement deleted");
		       break; 
	   	case 8:printf("enter position:");
		       scanf("%d",&pos);
		       head=delatpartpos(head,pos);
		       printf("\nelement deleted");
		       break; 	
	   case 9:printf("reverse of nodes\n");
	          head=reverse(head);
	          display(head);
			  break;        
	}printf("\npress 1 to continue:");
	scanf(" %d",&ch1);
  }while(ch1==1);
}

// create node 

struct node*addatEmpty(struct node*head,int data)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->prev=NULL;
	temp->data=data;
	temp->next=NULL;
	head=temp;
	return head;
	
}

// add at begin

struct node*addatBegin(struct node*head,int data)
{
	struct node*temp=malloc(sizeof(struct node)); //creating new node
	temp->prev=NULL;
	temp->data=data;
	temp->next=NULL;
	
	temp->next=head;
	head->prev=temp;
	head=temp;
	return head;	
}

// add at end 

struct node*addatEnd(struct node*head,int data)
{
	struct node*temp=malloc(sizeof(struct node)); 
	struct node*tp=head;//new pointer
	temp->prev=NULL;
	temp->data=data;
	temp->next=NULL;
	while(tp->next!=NULL)
	{
		tp=tp->next;
	}
	tp->next=temp;
	temp->prev=tp;
	return head;	
}

// display

void display(struct node*head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
    struct node*temp=head;
    printf("elements in nodes:\n");
    while(temp!=NULL)
    {
    	printf("%d\n",temp->data);
    	temp=temp->next;
	}
}

// insert at particular position

struct node*addatpartpos(struct node*head,int data,int pos)
{
	struct node*newp=NULL;
	struct node*temp=head;
	struct node*temp2=NULL;
	newp=addatEmpty(newp,data);
	while(pos!=1)
	{
		temp=temp->next;
		pos--;
	}
	if(temp->next==NULL)
	{
		temp->next=newp;
		newp->prev=temp;
	}
	else
	{
    temp2=temp->next;
	temp->next=newp;
	temp2->prev=newp;
	newp->next=temp2;
	newp->prev=temp;
	return head;
    }
}

//delete at begin

struct node*delatbegin(struct node*head)
{
	struct node*temp=head;
	head=head->next;
	free(temp);
	temp->prev=NULL;
	temp=NULL;
	return head;
}

//delete at end

struct node*delatend(struct node*head)
{
	struct node*temp=head;
	struct node*temp2;
	while(temp->next!=NULL)
	    temp=temp->next;
	temp2=temp->prev;
	temp2->next=NULL;
	free(temp);
	return head;
}

// delete at particular position

struct node*delatpartpos(struct node*head,int pos)
{
	struct node*temp=head;
	struct node*temp2=NULL;
	if(pos==1)
	{
		head=delatbegin(head);
		return head;
	}
	while(pos>1)
	{
		temp=temp->next;
		pos--;
	}
	if(temp->next==NULL)
	{
		head=delatend(head);
	}
	else
	{
		temp2=temp->prev;
		temp2->next=temp->next;
		temp->next->prev=temp2;
		free(temp);
		temp=NULL;
	}
	return head;
}

// reverse 

struct node*reverse(struct node*head)
{
	struct node*ptr1=head;
	struct node*ptr2=ptr1->next;
	
	ptr1->next=NULL;
	ptr1->prev=ptr2;
	
	while(ptr2!=NULL)
	{
		ptr2->prev=ptr2->next;
		ptr2->next=ptr1;
		ptr1=ptr2;
		ptr2=ptr2->prev;
	}
	head=ptr1;
	return head;	
}

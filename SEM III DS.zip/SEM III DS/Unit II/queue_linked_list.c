#include<stdio.h>
#include<stdlib.h>

int ch,ch1,n,count;

void enqueue(int); //insertion at end
void display(); //deletion at begin
int dequeue();
int peek();
int size();

struct node
{
    int data;
	struct node*link;	
}*front=NULL,*rear=NULL;

main()
{
	do
	{
		printf("1.Enqueue an element\n");
		printf("2.Display elements\n");
		printf("3.Dequeue an element\n");
		printf("4.Front of the linked list\n");
		printf("5.Size of the linked list\n");
		printf("enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter an element to be inserted:");
			       scanf("%d",&n);
			       enqueue(n);
			       break;
			case 2:display();
			       break;
			case 3:printf("popped element:%d",dequeue());
			       break;
			case 4:printf("front element:%d",peek());
			       break;	
			case 5:printf("size of the list:%d",size());
			       break;       
		}
		printf("\n press 1 to continue:");
		scanf(" %d",&ch1);		
	}while(ch1==1);
}

void enqueue(int data)
{
	struct node*temp;
	temp=malloc(sizeof(struct node));
	if(temp==NULL)
	printf("queue is full\n");
	temp->data=n;
	temp->link=NULL;
	
	// single node
	if(front==NULL && rear==NULL)
	{
		front=rear=temp;
		return;
	}
	
	rear->link=temp;
	
	rear=temp;
}

void display()
{
	struct node*temp;
	temp=front;
	if(front==NULL)
	printf("queue is empty\n");
	else
	{
	printf("elements in the list:\n");
	while(temp!=NULL)
	{
	   printf("%d\n",temp->data);
	   temp=temp->link;	
    }
   }
}

int dequeue()
{
	struct node*temp;
	int val;
	temp=front;
	if(front==NULL)
	printf("queue is empty\n");
	
	//single node
	if(front==rear)
	front=rear=NULL;
		
	else
	front=front->link;
	
	val=temp->data;// to store first node data some where
	free(temp);
	temp=NULL;	
	return val;
}

int peek()
{
	if(front==NULL)
	printf("queue is empty\n");
	return front->data;
}

int size()
{
	struct node*temp;
	temp=front;
	if(front==NULL)
	printf("queue is empty\n");
	while(temp!=NULL)
	{
	   count=count+1;
	   temp=temp->link;
    }
    return count;	
}

#include<stdio.h>
#include<stdlib.h>

int count=0,ch,ch1,n,pos;

void count_nodes();	
void display();
void insert_atend();
struct node*insert_atbegin();
void insert_atpos();
struct node*delfirstnode();
void delend();
void delatpos();
struct node*rev();

struct node
{
	int data;
	struct node*link;
};

main()
{
	struct node*head=NULL;
	head=malloc(sizeof(struct node));
	head->data=6;
	head->link=NULL;
	printf("\nFIRST NODE\n");
	printf("%d\n",head->data);// 6
	printf("%d\n",head->link);// NULL
	
	struct node*current=malloc(sizeof(struct node)); // for second node(new node is created)
	current->data=10;
	current->link=NULL;
	head->link=current;
	printf("\nSECOND NODE\n");
	printf("%d\n",current->data);// 10
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link);// address of first node(6)
	
	current=malloc(sizeof(struct node));// third node (it no longers points to second node)
	current->data=12;
	current->link=NULL;
	head->link->link=current;// address of second node
	printf("\nTHIRD NODE\n");
	printf("%d\n",current->data);// 12
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link->data);// variable in second node(10)
	printf("%d\n",head->link->link);// address of second node(10)
	
	current=malloc(sizeof(struct node));// fourth node (it no longers points to second node)
	current->data=15;
	current->link=NULL;
	head->link->link->link=current;// address of third node
	printf("\nFOURTH NODE\n");
	printf("%d\n",current->data);// 15
	printf("%d\n",current->link);// NULL
	printf("%d\n",head->link->link->data);// variable in third node(12)
	printf("%d\n",head->link->link->link);// address of third node(12)
	do
	{
		printf("1.To display all elements\n");
	    printf("2.To insert an element at the end\n");
	    printf("3.To insert an element at the begining\n");
	    printf("4.To insert an element at particular position\n");
	    printf("5.Deleting the first node\n");
	    printf("6.Deleting the last node\n");
	    printf("7.Deleting the node at the particular position\n");
	    printf("8.To reverse the nodes\n");
	    printf("9.Total no.of nodes\n");
		printf("enter your choice:");
        scanf("%d",&ch);
	    switch(ch)
	    {
	    	case 1:display(head);
	    	       break;
	    	case 2:printf("enter element to be inserted:");
	    	       scanf("%d",&n);
			       insert_atend(head,n);
	    	       printf("\nelement inserted");
	    	       break;
	    	case 3:printf("enter element to be inserted:");
	    	       scanf("%d",&n);
			       head=insert_atbegin(head,n);
	    	       printf("\nelement inserted");
	    	       break;
	        case 4:printf("enter element to be inserted:");
	    	       scanf("%d",&n);
	    	       printf("enter position:");
	    	       scanf("%d",&pos);
			       insert_atpos(head,n,pos);
	               printf("\nelement inserted");
	               break;
	        case 5:head=delfirstnode(head);
	               printf("\nelement deleted");
	               break;
	        case 6:delend(head);
	               printf("\nelement deleted");
	               break;
	        case 7:printf("enter position:");
	    	       scanf("%d",&pos);
	    	       delatpos(&head,pos);
				   printf("\nelement deleted");
	    	       break;
		    case 8:head=rev(head);
				   break;	       
	        case 9:count_nodes(head);
	               break;
	   }printf("\npress 1 to continue:");
	    scanf(" %d",&ch1);
	   
    }while(ch1==1);

}

void count_nodes(struct node *head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node *temp=head;
	while(temp!=NULL)
	{
		count=count+1;
		temp=temp->link;
	}
	printf("\nno.of nodes:%d\n\n",count);
}

void display(struct node *head)
{
	if(head==NULL)
	{
	   printf("linked list is empty");
    }
	struct node *temp=head;
	printf("elements in nodes:\n");
	while(temp!=NULL)
	{
		printf("%d\n",temp->data);// to print all nodes 
		temp=temp->link;
	}
}

// To insert a node at the end

void insert_atend(struct node *head,int n)
{
	struct node *temp,*ptr;
	temp=head;
	ptr=malloc(sizeof(struct node));
	ptr->data=n;
	ptr->link=NULL;
	while(temp->link!=NULL)
	{
		temp=temp->link;
	}
	temp->link=ptr;
}

// To insert a node at the begining

struct node*insert_atbegin(struct node*head,int n)
{
	struct node *ptr;
	ptr=malloc(sizeof(struct node));
	ptr->data=n;//50
	ptr->link=head;
	head=ptr;
	return head;
}

// To insert a node at particular position

void insert_atpos(struct node*head,int n,int pos)
{
	struct node *ptr2=malloc(sizeof(struct node));
	ptr2->data=n;
	ptr2->link=NULL;
	struct node *ptr=head;
	pos--;
	while(pos!=1)
	{
		ptr=ptr->link;
		pos--;
	}
	ptr2->link=ptr->link;
	ptr->link=ptr2;	
}

// Deleting the first node

struct node*delfirstnode(struct node*head)
{
	if(head==NULL)
	printf("linked list is empty");
	else
	{
		struct node*temp=head;
		head=temp->link;
		free(temp);
		temp=NULL;
		return head;
	}
}

// Deleting the last node

void delend(struct node*head)
{
	if(head==NULL)
	printf("linked list is empty");
	else if(head->link==NULL)
	{
		free(head);
		head=NULL;
	}
	struct node*temp=head;
	while(temp->link->link!=NULL)
	{
		temp=temp->link;
	}
	free(temp->link);
	temp->link=NULL;
}

// Deleting the node at a particular position

void delatpos(struct node **head,int pos)
{
	struct node*current=*head;
	struct node*prev=*head;
	if(*head==NULL)
	printf("linked list is empty");
	else if(pos==1)
	{
		*head=current->link;
		free(current);
		current=NULL;
	}
	while(pos!=1)
	{
		prev=current;
		current=current->link;
		pos--;
	}
	prev->link=current->link;
	free(current);
	current=NULL;
}

// Reverse 

struct node*rev(struct node*head,int pos)
{
	struct node*next=NULL;
	struct node*prev=NULL;
	while(head!=NULL)
	{
		next=head->link;
		head->link=prev;
		prev=head;
		head=next;
	}
	head=prev;
	return head;	
}

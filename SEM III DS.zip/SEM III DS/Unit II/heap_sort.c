#include<stdio.h>
#include<math.h>

#define MAX 100

int i,temp,lb,n,a[MAX],x,d,ch,ch1,t,l,r,max_child;

int parent(int);
int left(int);
int right(int);

void swap(int*,int*);
void display(int[],int);
void insert(int[],int,int,int);
int del(int[],int,int);

main()
{
    n=0;      
    lb=0;        
    do
    {
        printf("1.Insert an element\n");
        printf("2.Delete an element\n");
        printf("3.Display elements\n");
        printf("enter your choice:");
        scanf("%d",&ch);
        switch(ch)
        {
        case 1:printf("enter an element to be inserted:");
               scanf("%d",&x);
               insert(a,n,x,lb);
               n++;
               break;
        case 2:d=del(a,n,lb);
               if(d!=0)
               printf("Deleted Value:%d",d);
               if(n>0)
               n--;
               break;
        case 3:display(a,n);
               break;
       }printf("\n press 1 to continue:");
        scanf(" %d",&ch1);
   }while(ch1==1);	
}

void insert(int a[],int hs,int x,int lb)
{
    int p;
    if(hs==MAX)
    printf("Queue is full");
    i=lb+hs;
    a[i]=x;
    while(i>lb&&a[p=parent(i)]<a[i])
    {
        swap(&a[p],&a[i]);
        i=p;
    }
}
	
int del(int a[],int hs,int lb)
{
    if(hs==1)
    printf("Queue is empty");
    t=a[lb];
    swap(&a[lb],&a[hs-1]);					
    i=lb;
    hs--;
    while(1)
    {
        if((l=left(i))>=hs)
        break;
        if((r=right(i))>=hs)
        max_child=l;
        else
        max_child=(a[l]>a[r])?l:r;
        if(a[i]>=a[max_child])
        break;
        swap(&a[i],&a[max_child]);
        i=max_child;
    }
   return t;
}

int parent(int i)
{
    float p;
    p=((float)i/2.0)-1.0;
    return ceil(p);
}

int left(int i)
{
    return 2*i+1;
}

int right(int i)
{
    return 2*i+2;
}
		
void display(int a[],int n)
{
    if(n==0)
    printf("Queue is empty");
    for(i=0;i<n;i++)
    printf("%d\n",a[i]);
}

void swap(int*p,int*q)
{
    temp=*p;
    *p=*q;
    *q=temp;
}


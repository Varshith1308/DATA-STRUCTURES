#include<stdio.h>
int mergesort(int[],int,int);
int merge(int[],int,int,int);
int a[100],i,j,n,t,l,h,mid,mi,t[100],k;
main()
{
	printf("enter the size:");
	scanf("%d",&n);
	printf("enter elements:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	mergesort(a,0,n-1);
	printf("elements after sorted\n");
	for(i=0;i<n;i++)
	printf("%d\n",a[i]);	
}
int mergesort(int a[],int l,int h)
{
	int m;
	if(l<h)
	{
		mid=(l+h)/2;
		mergesort(a,l,mid);
		mergesort(a,mid+1,h);
		merge(a,l,m,h);
	}
}
int merge(int a[],int l,int mid,int h)
{
	int lower=l,i=l,mi=mid+1;
	while(lower<=mid && mi<=high)
	{
		if(a[l]<=a[mid])
		{
		  t[i]=a[lower];
		  lower++;
	    }
		else
		{
			t[i]=a[mi];
			mi++;
		}
		i++;
	}
	if(lower>mid)
	{
		for(k=mi;k<=h;k++)
		{
			t[i]=a[k];
			i++;
		}
	}
	else
	{
		for(k=lower;k<=mid;k++)
		{
			t[i]=a[k];
			i++;
		}
		
	}
	for(k=l;k<=h;k++)
	a[k]=t[k];
}

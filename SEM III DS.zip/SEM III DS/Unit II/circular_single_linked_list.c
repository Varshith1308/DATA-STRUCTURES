#include<stdio.h>
#include<stdlib.h>

int ch1,ch,n,pos;

struct node*insertatempty();
struct node*insertatbegin();
void display();
struct node*insertatend();
struct node*insertatpartpos();
struct node*delatbegin();
struct node*delatend();
struct node*delatpartpos();

struct node
{
	int data;
	struct node*link;
};

main() 
{
	int data;
	struct node*tail;
	do
	{
		printf("1.Add a node\n");
		printf("2.Insert at begin\n");
		printf("3.Display nodes\n");
		printf("4.Insert at end\n");
		printf("5.Insert at particular position\n");
		printf("6.Delete at begin\n");
		printf("7.Delete at end\n");
		printf("8.Delete at particular position\n");
		printf("enter your choice:");
	    scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatempty(tail,n);
				   break;
		    case 2:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatbegin(tail,n);
		           printf("\nelement inserted");
		           break;
		    case 3:printf("elements in nodes\n");
		           display(tail);
		           break;
		    case 4:printf("enter element to be inserted:");
		           scanf("%d",&n);
			       tail=insertatend(tail,n);
		           printf("\nelement inserted");
		           break;
		    case 5:printf("enter element to be inserted:");
		           scanf("%d",&n);
		           printf("enter position:");
		           scanf("%d",&pos);
			       tail=insertatpartpos(tail,n,pos);
		           printf("\nelement inserted");
		           break;
		    case 6:tail=delatbegin(tail);
		           printf("\nelement deleted");
		           break;
		    case 7:tail=delatend(tail);
		           printf("\nelement deleted");
		           break;
		    case 8:printf("enter position:");
		           scanf("%d",&pos);
			       tail=delatpartpos(tail,pos);
		           printf("\nelement deleted");
		           break;
		}
		printf("\n press 1 to continue:");
		scanf(" %d",&ch1);
	}while(ch1==1);
}

struct node*insertatempty(struct node*tail,int data)
{
	struct node*temp=malloc(sizeof(struct node));
	temp->data=data;
	temp->link=temp;
	printf("%d",temp->data);
	return temp;
}

struct node*insertatbegin(struct node*tail,int data)
{
	struct node*newp=malloc(sizeof(struct node));
	newp->data=data;
	newp->link=tail->link;
	tail->link=newp;
	return tail;	
}

void display(struct node*tail)
{
	struct node*p=tail->link;
	do
	{
		printf("%d\n",p->data);
		p=p->link;
	}while(p!=tail->link);
}

struct node*insertatend(struct node*tail,int data)
{
	struct node*newp=malloc(sizeof(struct node));
	newp->data=data;
	newp->link=NULL;
	
	newp->link=tail->link;
	tail->link=newp;
	tail=tail->link;
	return tail;
}

struct node*insertatpartpos(struct node*tail,int data,int pos)
{
	struct node*p=tail->link;
	struct node*newp=malloc(sizeof(struct node));
	newp->data=data;
	newp->link=NULL;
	while(pos>1)
	{
		p=p->link;
		pos--;
	}
	newp->link=p->link;
	p->link=newp;
	if(p==tail)
	{
		tail=tail->link;
	}
	return tail;
}

struct node*delatbegin(struct node*tail)
{
	struct node*temp;
	temp=tail->link;
	
	tail->link=temp->link;
	free(temp);
	temp=NULL;
	return tail;
}

struct node*delatend(struct node*tail)
{
	struct node*temp=tail->link;
    while(temp->link!=tail)	
	temp=temp->link;
	temp->link=tail->link;
	free(tail);
	tail=temp;
	return tail;
}

struct node*delatpartpos(struct node*tail,int pos)
{
	struct node*temp=tail->link;
	while(pos>2)
	{
		temp=temp->link;
		pos--;
	}
	struct node*temp2=temp->link;
	temp->link=temp2->link;
	free(temp2);
	temp2=NULL;
	return tail;
}

#include<stdio.h>

void dfs();

int v,a[50][50],visited[20],n,i,j;
main()
{
	printf("enter the number of vertices:");
	scanf("%d",&n);
	
	for(i=0;i<n;i++) 
	{
		visited[i]=0;
	}
	printf("enter adjacent matrix:\n");
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d ",&a[i][j]);
		}
    }
			
	printf("enter the starting vertex:");
	scanf("%d",&v);
	
	printf("\n DFS Traversal is :");
	printf("%d",v);
	dfs(v);
}

void dfs(int v)
{
	visited[v]=1;
	for(i=0;i<n;i++)
	{
		if(a[v][i]!=0 && visited[i]==0) 
		{	
			printf("%d ",i);
			dfs(i);
		}
	}	
}



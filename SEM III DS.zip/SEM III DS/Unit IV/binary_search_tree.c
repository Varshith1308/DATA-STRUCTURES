#include<stdio.h>
#include<stdlib.h>

int key,ch,ch1,flag;

void insert();
void inorder();
struct node*search();
void preorder();
void postorder();
struct node *findMin();
struct node*delete();

struct node
{
	struct node*lchild;
	int data;
	struct node*rchild;
}*root=NULL;

main()
{
	struct node*temp;
	do
	{
		printf("1.Insert an element\n");
		printf("2.Display Inordered list\n");
		printf("3.Search an element\n");
		printf("4.Display Preordered list\n");
		printf("5.Display Postordered list\n");
		printf("6.Delete an element\n");

        printf("enter your choice:");
        scanf("%d",&ch);
        switch(ch)
        {
        	case 1:printf("enter an element to be inserted:");
        	       scanf("%d",&key);
        	       insert(key);
        	       break;
        	case 2:printf("Display Inordered list\n");
			       inorder(root);
        	       break;
		    case 3:printf("enter an element to be search:");
        	       scanf("%d",&key);
        	       temp=search(key);
        	       if(temp!=NULL)
        	       printf("%d",temp->data);
        	       else
        	       printf("element is not found");
        	       break; 
			case 4:printf("Display Preordered list\n");
			       preorder(root);
        	       break;
			case 5:printf("Display Postordered list\n");
			       postorder(root);
        	       break;
			case 6:
				printf("enter an element to deleted:");
				scanf("%d",&key);
				root=delete(root,key);
				printf("element deleted\n");
				break;
      	       
		}printf("\n press 1 to continue:");
		scanf(" %d",&ch1);
	}while(ch1==1);
}

void insert(int key)
{
	struct node*t=root;
	struct node*r,*p;
	if(root==NULL)
	{
		p=malloc(sizeof(struct node));
		p->data=key;
		p->lchild=p->rchild=NULL;
		root=p;
		return;
    }
		while(t!=NULL)	
		{
			r=t;
			if(key<(t->data))
			t=t->lchild;
			else if(key>(t->data))
			t=t->rchild;
			else
			return;	
		}
		p=malloc(sizeof(struct node));
		p->data=key;
		p->lchild=p->rchild=NULL;
		if(key<(r->data))
		r->lchild=p;
		else
		r->rchild=p;			
}

void inorder(struct node*p)
{
	if(p)
	{
		inorder(p->lchild);
		printf("%d\n",p->data);
		inorder(p->rchild);
	}
}

struct node*search(int key)
{
	struct node*t=root;
	while(t!=NULL)
	{
		if(key==(t->data))
		return t;
	    else if(key<(t->data))
		t=t->lchild;
		else 
		t=t->rchild;
    }
		return NULL;
}

void preorder(struct node*p)
{
	if(p)
	{
		printf("%d\n",p->data);
		preorder(p->lchild);
		preorder(p->rchild);
	}
}


void postorder(struct node*p)
{
	if(p)
	{
        postorder(p->lchild);
		postorder(p->rchild);
        printf("%d\n",p->data);
	}
}

struct node *findMin(struct node*p)
{
	if(p->lchild==NULL)
	{
		return p;
	}
	return findMin(p->lchild);
}

struct node *delete(struct node*current,int key)
{
	flag=0;
	if(current==NULL)
	{
		return NULL;
	}
	else if(key< current->data)
	{
		current->lchild=delete(current->lchild,key);
	}
	else if(key>current->data)
	{
		current->rchild=delete(current->rchild,key);
	}
	else
	{
	    flag=1;
		if(current->lchild==NULL&&current->rchild==NULL)
		{
			current=NULL;
		}
		else if(current->lchild==NULL)
		{
			current=current->rchild;
		}
		else if(current->rchild==NULL)
		{
            current=current->lchild;
		}
		else
		{
			struct node *temp=findMin(current->rchild);
			current->data=temp->data;
			current->rchild=delete(current->rchild,temp->data);
		}
	}
	return current;

}
